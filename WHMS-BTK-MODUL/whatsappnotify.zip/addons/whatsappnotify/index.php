<?php

echo "<p align=\"center\">360Messenger.com</p>\r\n\r\n\r\n\r\n\r\n";

?>