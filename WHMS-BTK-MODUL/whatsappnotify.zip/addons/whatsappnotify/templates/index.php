<?php

echo "<p align=\"center\">360messenger.com</p>\r\n\r\n\r\n\r\n\r\n";

?>