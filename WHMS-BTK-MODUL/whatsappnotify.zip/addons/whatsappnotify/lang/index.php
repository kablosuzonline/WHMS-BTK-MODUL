<?php //ICB0 74:0 81:889 82:b9d                                               ?><?php //0058a
// WhatsApp Notify 7.3.1
// 
// Copyright 2024 WHMCS Services
// 
// This license permits you to install this software on a single domain, single website, with a single IP address. You may not remove any copyright information either from the php source code, or from the HTML source code.
// 
// You may not reverse engineer, decompile, defeat licensing, or disassemble this software product or software licensing system in any way.  WHMCS Services may terminate this license if for any reason you do not comply with the terms and conditions as set forth in the end-user license agreement (EULA) included with this software to which you have agreed to by posessing, installing, or using this software.
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsNxsGETNI8qM41C8DJ5eEsBjtqAeeyc5/9laoxxqLnGe3/VtolfTH4j8lBc6hxUsYHT6GrV
HP8LBuVUxxynteyJvnhBXSsA9MViz8q6ssNDzEqXYlJ0UvfivAWNO+ygzxx8qQR68ehQa46dHFRr
hpJz7dl8JE99rYMxnjTVhakMDNTaIw6xltTee4Wu+lNls02SQ6bc4/ou5THZy2C96/pTyQbndJlf
tOIVpv53wgJzDJu8r1s6pCZnmKtXc4K9GDkgeyu92DeJQs31fjhwVyJ+wba4Sou+814lGqgV8XuH
m3FYMZwyfOL3WO6QurwuI4cpAtSv46Fe+PrWKEIogpDnN3hYHwgywviH/xfMs334VJbH5uZute2E
1kxWaNR+nSHpmfgNHS0+UdaK4KIZW/MJWPTrJlkC5Y3t1nLR62ClVduiXxtrBAYRjYhYSINSqrEp
6iV3Rw18/x0pycV1KXjUO28DPb/uPKiBuPlUIpOtMFNCMcBPRRMiPfBGrdnRmo2lHVmbg4G7HL3C
it1uFLbpS4wxw1qYNTL3wycTC1Fi15kqGXvLTmiBLP4o0HSGEW3lDjLBBjMgDLAPbOLXRBNB7UTG
RtBc07wTE/bEYbDETrqQqcX5WRA7yHXIaULsDxlylVyoRYnxGgNWh0epezjwPWBIrZXSVrgSxNJc
BxBf1SmH10lHL2B0dlzhGnf87m0izJiTqLVSkUbOuC/lVxubyXW6ppbaAhhGdgaqdvEk=
HR+cPx/ehqn+I1HZ1rOwRtVwxyqZmwJaYSdfxvYuOhAVMZ1lsvj3NNy0Gf+Y6egM7+JAnN+61wXk
jgTT01Xm29KOS0c6qoK9gvA+aUhgUFupt9NQvUUmm8AvrSCiv8trbhDXxv9U+Xl1hJWf+Xcd6Xa1
/H3ooC0FRX5YHkSDNLSbGZfLgf1q4paEUKQgyABqy9zyqC8Az67+37Zr6PzhaZANhRaQyG7kWrwP
jMUc4VBHt9D0oOzZSSj4i1p7oMcGfvx8Sjsl7aU9ysO10RRr7ls7pwpvJrfkNG/LSJjHxjfghkfQ
WUDACva5o74VsnfFO4Gc/4mxS5vNCJO/ZReBVCdHDBrcyx95oH0X4g1fp729/K6hqae2W41TIehz
5dwoeKtGUcZkJv5yfhuXSpiMyLxaMeQHFeFe0P38lHigWZ2cFSzUEXXoGW9PUtKmiOFdWDSATl0H
I8B9Vu5hcHyVQGMsl8W1uRa2PL6AHQknLlHh62wWbpz6Q7ujsrmlKq0zwKe2fNpoDBfuNKmjfdQQ
AYrQINqVaQvO5EyXUmcMUm5CQdu1/TbcagJ/WFqg/AuR/Fcgbp9m1pTKikX4VUqLsclFtzpXKzQe
w745kZaOm0vhSLaJOzmtzxbo1MjrUqXIuNKv0OmOcKKFN5+t7s9H22pA+LktchxROkgqz8LQIO5Q
VvRSi4eWpCABS7ktw+F0H9GGxtQMtbHpDiy8lBB+vZuQ+0BIC2F0BOFd2QrbLH0hLqy4a1IUMXnM
CNKx3/Z/gT2WFYy==
HR+cPv1EpQ9IeZMLA/1OWNwWtaQ2j3D8lk7H1SvmXPX7u8A1ksEI6ywfNBu2i7rrXDc/rEwHZ+ZW
emJxwrPZAY0AEwGhXxfxBls5QFZOjBNQs4bvsbuXkMrFDiuKc0DzSGdDHvdv+uwDI5evwHz+/+rH
MYI7tNXRC+FdzhCOus1lhQjnROkLiBYCn9CuMDqrvToGqS+2YsYRaJS7f9pQasTchbGSy+DuCt2W
eqQbGiUUha3LcauvD6CeTnlOZIu8ogvUEOgo4KmRndgq0CbJko2T9fWhpMbfysqi8hSGMyQcq3HH
TMd2ct3//rFGHWP2kNkOchewQoSvSpBxiXyxmTU+X8ycvFIvL8pGtNkAzI52894BGHVFQhUN2rh0
m2ujSCWiPGR5vIA10XmvrVETGW2ivhUswzW3UyKQKOJsVwJnAW89q77WuD1PFUSepyEXyxvJyzD1
Nqvsio/egXLTkJtD/mdpfUmgJffNyisOBfQywzxMPU5mxy/SdpbEUfR28O4H3/repC8fCgudY3eZ
2A3aOrTd+/e1numV2FvwYM0KdGVHHBexmlYgQRFvTfqPdqbbq64kX9v5h47mSo84EZPp4y3rvHvZ
EaVKqb35y8g/VyEOu7be4IbkZUf6qZ1Y2JEVVFOOrnMYArHCNY5AReco0MMw5meXJU/6dq+ad6Wu
YM9gib/H0Hk0/QQnLVzMjsdGp8Z8bZcoZeRqrMfQKAFmnt4xLzs8p3qk5PPkzOa0BhNlAv0oOdUB
jSmariIX6gw9oW==